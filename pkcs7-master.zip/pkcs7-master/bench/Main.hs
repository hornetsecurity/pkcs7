module Main ( main ) where

import           Criterion.Main

main :: IO ()
main = defaultMain $ []
